import os
import tempfile
import unittest
from pathlib import Path

_TEST_DIR = tempfile.TemporaryDirectory()
os.environ["ENROLLIO_DB_PATH"] = str(Path(_TEST_DIR.name) / "test.db")
os.environ["ENROLLIO_ADMIN_EMAIL"] = "admin@test.local"
os.environ["ENROLLIO_ADMIN_PASSWORD"] = "TestPassword@123"

import app as enrollio


class EnrollioApiTests(unittest.TestCase):
    def setUp(self):
        with enrollio.db_session() as conn:
            conn.execute("DELETE FROM activity_logs")
            conn.execute("DELETE FROM students")
            conn.execute("DELETE FROM sessions")
        self.client = enrollio.app.test_client()

    def login(self):
        return self.client.post("/api/login", json={"email": "admin@test.local", "password": "TestPassword@123"})

    def sample_student(self, email="aanya@example.com"):
        return {
            "full_name": "Aanya Sharma",
            "email": email,
            "phone": "9876543210",
            "date_of_birth": "2005-04-18",
            "programme": "Bachelor of Computer Applications (BCA)",
            "entry_term": "January 2027",
            "notes": "Test record",
        }

    def test_health(self):
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json["success"])

    def test_admin_login_and_current_user(self):
        response = self.login()
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json["success"])
        me = self.client.get("/api/me")
        self.assertEqual(me.status_code, 200)
        self.assertEqual(me.json["user"]["role"], "admin")

    def test_protected_endpoint_requires_login(self):
        response = self.client.get("/api/dashboard/stats")
        self.assertEqual(response.status_code, 401)

    def test_create_student_and_stats(self):
        self.login()
        response = self.client.post("/api/students", json=self.sample_student())
        self.assertEqual(response.status_code, 201, response.json)
        self.assertEqual(response.json["student"]["status"], "Pending")
        stats = self.client.get("/api/dashboard/stats")
        self.assertEqual(stats.status_code, 200)
        self.assertEqual(stats.json["stats"]["total"], 1)
        self.assertEqual(stats.json["stats"]["pending"], 1)

    def test_duplicate_email_rejected_case_insensitively(self):
        self.login()
        self.assertEqual(self.client.post("/api/students", json=self.sample_student()).status_code, 201)
        response = self.client.post("/api/students", json=self.sample_student("AANYA@example.com"))
        self.assertEqual(response.status_code, 409)

    def test_invalid_phone_rejected(self):
        self.login()
        data = self.sample_student()
        data["phone"] = "123"
        response = self.client.post("/api/students", json=data)
        self.assertEqual(response.status_code, 400)
        self.assertIn("phone", response.json["errors"])

    def test_status_update_and_csv_export(self):
        self.login()
        created = self.client.post("/api/students", json=self.sample_student())
        student_id = created.json["student"]["student_id"]
        response = self.client.patch(f"/api/students/{student_id}/status", json={"status": "Approved"})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json["student"]["status"], "Approved")
        export = self.client.get("/api/reports/export.csv")
        self.assertEqual(export.status_code, 200)
        self.assertIn(b"Aanya Sharma", export.data)

    def test_logout_invalidates_session(self):
        self.login()
        self.assertEqual(self.client.get("/api/me").status_code, 200)
        self.client.post("/api/logout")
        self.assertEqual(self.client.get("/api/me").status_code, 401)


if __name__ == "__main__":
    unittest.main()
