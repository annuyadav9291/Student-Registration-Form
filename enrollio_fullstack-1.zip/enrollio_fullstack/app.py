import csv
from contextlib import contextmanager
import io
import os
import re
import secrets
import sqlite3
from datetime import date, datetime, timedelta, timezone
from functools import wraps
from pathlib import Path

from flask import Flask, jsonify, make_response, render_template, request, send_file
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("ENROLLIO_DB_PATH", BASE_DIR / "enrollio.db"))
SESSION_HOURS = 24
STATUSES = {"Pending", "In review", "Approved", "Incomplete"}
PROGRAMMES = {
    "Bachelor of Computer Applications (BCA)": "BCA",
    "Bachelor of Business Administration (BBA)": "BBA",
    "Bachelor of Commerce (B.Com)": "B.Com",
    "Bachelor of Arts (BA)": "BA",
    "Bachelor of Science (B.Sc)": "B.Sc",
    "Master of Computer Applications (MCA)": "MCA",
}
ENTRY_TERMS = {"January 2027", "July 2027", "January 2028"}

app = Flask(__name__)
app.config.update(JSON_SORT_KEYS=False)


def connect_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def db_session():
    conn = connect_db()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    with db_session() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            email TEXT NOT NULL UNIQUE COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'admin' CHECK(role IN ('admin','user')),
            status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','inactive')),
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS sessions (
            session_id TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(user_id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
        CREATE TABLE IF NOT EXISTS students (
            student_id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE COLLATE NOCASE,
            phone TEXT NOT NULL,
            date_of_birth TEXT NOT NULL,
            programme TEXT NOT NULL,
            entry_term TEXT NOT NULL,
            notes TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'Pending'
                CHECK(status IN ('Pending','In review','Approved','Incomplete')),
            submitted_at TEXT NOT NULL,
            created_by INTEGER,
            FOREIGN KEY(created_by) REFERENCES users(user_id) ON DELETE SET NULL
        );
        CREATE INDEX IF NOT EXISTS idx_students_submitted ON students(submitted_at DESC);
        CREATE INDEX IF NOT EXISTS idx_students_status ON students(status);
        CREATE TABLE IF NOT EXISTS activity_logs (
            log_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            student_id INTEGER,
            action TEXT NOT NULL,
            details TEXT NOT NULL DEFAULT '',
            timestamp TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(user_id) ON DELETE SET NULL,
            FOREIGN KEY(student_id) REFERENCES students(student_id) ON DELETE SET NULL
        );
        """)
        # Demo administrator for local coursework. Change these credentials before deployment.
        admin_email = os.environ.get("ENROLLIO_ADMIN_EMAIL", "admin@enrollio.local").strip().lower()
        admin_password = os.environ.get("ENROLLIO_ADMIN_PASSWORD", "Admin@12345")
        existing = conn.execute("SELECT user_id FROM users WHERE email = ?", (admin_email,)).fetchone()
        if not existing:
            conn.execute(
                "INSERT INTO users(username,email,password_hash,role) VALUES(?,?,?,?)",
                ("admin", admin_email, generate_password_hash(admin_password), "admin"),
            )


def log_activity(conn, user_id, action, details="", student_id=None):
    conn.execute(
        "INSERT INTO activity_logs(user_id,student_id,action,details,timestamp) VALUES(?,?,?,?,?)",
        (user_id, student_id, action, details[:300], datetime.now(timezone.utc).isoformat()),
    )


def clean_user(row):
    return {"user_id": row["user_id"], "username": row["username"], "email": row["email"], "role": row["role"]}


def current_user():
    token = request.cookies.get("session_id")
    if not token:
        return None
    now = datetime.now(timezone.utc)
    with db_session() as conn:
        session = conn.execute(
            "SELECT s.session_id,s.expires_at,u.user_id,u.username,u.email,u.role,u.status "
            "FROM sessions s JOIN users u ON u.user_id=s.user_id WHERE s.session_id=?",
            (token,),
        ).fetchone()
        if not session:
            return None
        try:
            expires = datetime.fromisoformat(session["expires_at"])
        except ValueError:
            conn.execute("DELETE FROM sessions WHERE session_id=?", (token,))
            return None
        if expires <= now or session["status"] != "active":
            conn.execute("DELETE FROM sessions WHERE session_id=?", (token,))
            return None
        return session


def login_required(admin_only=True):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            user = current_user()
            if not user:
                return jsonify(success=False, message="Authentication required."), 401
            if admin_only and user["role"] != "admin":
                return jsonify(success=False, message="Administrator access required."), 403
            return fn(user, *args, **kwargs)
        return wrapper
    return decorator


def validate_student(data):
    errors = {}
    name = str(data.get("full_name", "")).strip()
    email = str(data.get("email", "")).strip().lower()
    phone = re.sub(r"\D", "", str(data.get("phone", "")))
    dob = str(data.get("date_of_birth", "")).strip()
    programme = str(data.get("programme", "")).strip()
    term = str(data.get("entry_term", "")).strip()
    notes = str(data.get("notes", "")).strip()

    if len(name) < 2 or len(name) > 80 or not re.search(r"[A-Za-zÀ-ÿ]", name):
        errors["full_name"] = "Enter a name between 2 and 80 characters."
    if len(email) > 120 or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]{2,}", email):
        errors["email"] = "Enter a valid email address."
    if not re.fullmatch(r"\d{10}", phone):
        errors["phone"] = "Phone number must contain exactly 10 digits."
    try:
        birth_date = date.fromisoformat(dob)
        if birth_date >= date.today():
            errors["date_of_birth"] = "Date of birth must be in the past."
    except ValueError:
        errors["date_of_birth"] = "Choose a valid date of birth."
    if programme not in PROGRAMMES:
        errors["programme"] = "Choose a valid programme."
    if term not in ENTRY_TERMS:
        errors["entry_term"] = "Choose a valid entry term."
    if len(notes) > 300:
        errors["notes"] = "Notes must be 300 characters or fewer."
    return errors, {
        "full_name": name, "email": email, "phone": phone, "date_of_birth": dob,
        "programme": programme, "entry_term": term, "notes": notes,
    }


@app.get("/")
def home():
    return render_template("index.html")


@app.get("/api/health")
def health():
    return jsonify(success=True, message="Enrollio API is running.")


@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}
    email = str(data.get("email", "")).strip().lower()
    password = data.get("password", "")
    with db_session() as conn:
        user = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if not user or user["status"] != "active" or not check_password_hash(user["password_hash"], password):
            return jsonify(success=False, message="Invalid email or password."), 401
        token = secrets.token_urlsafe(32)
        now = datetime.now(timezone.utc)
        expires = now + timedelta(hours=SESSION_HOURS)
        conn.execute("DELETE FROM sessions WHERE expires_at <= ?", (now.isoformat(),))
        conn.execute("INSERT INTO sessions(session_id,user_id,created_at,expires_at) VALUES(?,?,?,?)",
                     (token, user["user_id"], now.isoformat(), expires.isoformat()))
        log_activity(conn, user["user_id"], "Logged in", "Administrator signed in")
        response = make_response(jsonify(success=True, message="Login successful.", user=clean_user(user)))
        response.set_cookie("session_id", token, httponly=True, samesite="Lax", secure=os.environ.get("ENROLLIO_SECURE_COOKIE") == "1", max_age=SESSION_HOURS * 3600, path="/")
        return response


@app.post("/api/logout")
def logout():
    token = request.cookies.get("session_id")
    with db_session() as conn:
        if token:
            row = conn.execute("SELECT user_id FROM sessions WHERE session_id=?", (token,)).fetchone()
            if row:
                log_activity(conn, row["user_id"], "Logged out", "Administrator signed out")
            conn.execute("DELETE FROM sessions WHERE session_id=?", (token,))
    response = make_response(jsonify(success=True, message="Logged out successfully."))
    response.delete_cookie("session_id", path="/")
    return response


@app.get("/api/me")
def me():
    user = current_user()
    if not user:
        return jsonify(success=False, message="Not authenticated."), 401
    return jsonify(success=True, user=clean_user(user))


@app.get("/api/dashboard/stats")
@login_required()
def dashboard_stats(user):
    with db_session() as conn:
        rows = conn.execute("SELECT status,COUNT(*) AS count FROM students GROUP BY status").fetchall()
        counts = {r["status"]: r["count"] for r in rows}
        total = sum(counts.values())
        approved = counts.get("Approved", 0)
        return jsonify(success=True, stats={
            "total": total, "pending": counts.get("Pending", 0),
            "approved": approved, "incomplete": counts.get("Incomplete", 0),
            "in_review": counts.get("In review", 0),
            "approval_rate": round(approved / total * 100) if total else 0,
            "completion_rate": round((total - counts.get("Incomplete", 0)) / total * 100) if total else 0,
        })


@app.get("/api/students")
@login_required()
def list_students(user):
    q = str(request.args.get("q", "")).strip()[:100]
    status = str(request.args.get("status", "")).strip()
    limit = min(max(request.args.get("limit", default=100, type=int), 1), 500)
    where, params = [], []
    if q:
        where.append("(full_name LIKE ? OR email LIKE ? OR programme LIKE ? OR entry_term LIKE ?)")
        params.extend([f"%{q}%"] * 4)
    if status in STATUSES:
        where.append("status=?")
        params.append(status)
    clause = " WHERE " + " AND ".join(where) if where else ""
    with db_session() as conn:
        rows = conn.execute(
            "SELECT student_id,full_name,email,phone,date_of_birth,programme,entry_term,notes,status,submitted_at "
            f"FROM students{clause} ORDER BY submitted_at DESC LIMIT ?", (*params, limit)
        ).fetchall()
    return jsonify(success=True, students=[dict(r) for r in rows])


@app.post("/api/students")
@login_required()
def create_student(user):
    data = request.get_json(silent=True) or {}
    errors, values = validate_student(data)
    if errors:
        return jsonify(success=False, message="Please correct the highlighted fields.", errors=errors), 400
    now = datetime.now(timezone.utc).isoformat()
    with db_session() as conn:
        duplicate = conn.execute("SELECT student_id FROM students WHERE email=?", (values["email"],)).fetchone()
        if duplicate:
            return jsonify(success=False, message="A student with this email already exists.", errors={"email": "This email is already registered."}), 409
        cursor = conn.execute(
            "INSERT INTO students(full_name,email,phone,date_of_birth,programme,entry_term,notes,status,submitted_at,created_by) "
            "VALUES(?,?,?,?,?,?,?,'Pending',?,?)",
            (values["full_name"], values["email"], values["phone"], values["date_of_birth"], values["programme"], values["entry_term"], values["notes"], now, user["user_id"]),
        )
        student_id = cursor.lastrowid
        log_activity(conn, user["user_id"], "New application added", f"{values['full_name']} · {PROGRAMMES[values['programme']]}", student_id)
        row = conn.execute("SELECT * FROM students WHERE student_id=?", (student_id,)).fetchone()
    return jsonify(success=True, message="Enrollment saved successfully.", student=dict(row)), 201


@app.patch("/api/students/<int:student_id>/status")
@login_required()
def update_student_status(user, student_id):
    data = request.get_json(silent=True) or {}
    status = data.get("status")
    if status not in STATUSES:
        return jsonify(success=False, message="Invalid status.", allowed_statuses=sorted(STATUSES)), 400
    with db_session() as conn:
        student = conn.execute("SELECT full_name,status FROM students WHERE student_id=?", (student_id,)).fetchone()
        if not student:
            return jsonify(success=False, message="Student application not found."), 404
        conn.execute("UPDATE students SET status=? WHERE student_id=?", (status, student_id))
        log_activity(conn, user["user_id"], "Application status changed", f"{student['full_name']}: {student['status']} → {status}", student_id)
        row = conn.execute("SELECT * FROM students WHERE student_id=?", (student_id,)).fetchone()
    return jsonify(success=True, message="Status updated.", student=dict(row))


@app.get("/api/activity")
@login_required()
def activity_feed(user):
    limit = min(max(request.args.get("limit", default=8, type=int), 1), 50)
    with db_session() as conn:
        rows = conn.execute(
            "SELECT a.log_id,a.action,a.details,a.timestamp,u.username "
            "FROM activity_logs a LEFT JOIN users u ON u.user_id=a.user_id "
            "ORDER BY a.log_id DESC LIMIT ?", (limit,)
        ).fetchall()
    return jsonify(success=True, activities=[dict(r) for r in rows])


@app.get("/api/reports/summary")
@login_required()
def report_summary(user):
    with db_session() as conn:
        by_status = conn.execute("SELECT status,COUNT(*) AS count FROM students GROUP BY status ORDER BY status").fetchall()
        by_programme = conn.execute("SELECT programme,COUNT(*) AS count FROM students GROUP BY programme ORDER BY count DESC,programme").fetchall()
        by_term = conn.execute("SELECT entry_term,COUNT(*) AS count FROM students GROUP BY entry_term ORDER BY entry_term").fetchall()
    return jsonify(success=True, by_status=[dict(r) for r in by_status], by_programme=[dict(r) for r in by_programme], by_term=[dict(r) for r in by_term])


@app.get("/api/reports/export.csv")
@login_required()
def export_csv(user):
    with db_session() as conn:
        rows = conn.execute("SELECT student_id,full_name,email,phone,date_of_birth,programme,entry_term,notes,status,submitted_at FROM students ORDER BY submitted_at DESC").fetchall()
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(["Student ID", "Full name", "Email", "Phone", "Date of birth", "Programme", "Entry term", "Notes", "Status", "Submitted at"])
    for row in rows:
        writer.writerow([row[k] for k in row.keys()])
    binary = io.BytesIO(output.getvalue().encode("utf-8-sig"))
    binary.seek(0)
    return send_file(binary, mimetype="text/csv; charset=utf-8", as_attachment=True, download_name="enrollio_applications.csv")


init_db()

if __name__ == "__main__":
    # Debug is intended for local development only; do not expose this server publicly.
    app.run(host="127.0.0.1", port=5000, debug=True)
