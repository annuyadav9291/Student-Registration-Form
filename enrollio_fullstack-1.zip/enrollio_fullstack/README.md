# Enrollio — Digital Enrollment System

A working full-stack coursework project based on the supplied Enrollio admin-dashboard design. The original HTML/CSS design is retained and connected to a Flask API and SQLite database. Flask serves the page and API from the same origin, so session cookies work without a separate React dev server or CORS setup.

## Features

- Administrator login and logout using Werkzeug password hashing and server-side sessions.
- HTTP-only session cookie with a 24-hour expiry.
- SQLite persistence for users, sessions, student applications, and activity logs.
- Server-side validation for names, email, 10-digit phone numbers, date of birth, programme, term, and notes.
- Duplicate email prevention (case-insensitive) enforced in both application logic and a database UNIQUE constraint.
- Live dashboard statistics derived from database records.
- Student search, status filtering through status controls, and status changes (Pending, In review, Approved, Incomplete).
- Activity feed and CSV report export.
- Parameterized SQL queries and escaped user-provided text in rendered table rows.

## Requirements

- Python 3.10 or newer
- `pip`

## Run on Windows (PowerShell)

Open PowerShell in this folder (`enrollio_fullstack`).

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000.

### Demo administrator login

- Email: `admin@enrollio.local`
- Password: `Admin@12345`

These are local demo credentials only. Change them before using the app outside a private development environment. On first run the administrator is created automatically. If you change `ENROLLIO_ADMIN_PASSWORD` after the account has already been created, it will **not** reset the existing password automatically.

Optional environment variables (set before the first run):

```powershell
$env:ENROLLIO_ADMIN_EMAIL = "your-admin@example.com"
$env:ENROLLIO_ADMIN_PASSWORD = "use-a-unique-strong-password"
# Set to 1 only when running behind HTTPS:
$env:ENROLLIO_SECURE_COOKIE = "1"
python app.py
```

The database is created as `enrollio.db` in this folder. To reset the local demo completely, stop the server and delete `enrollio.db`; the next launch creates a fresh database. This deletes all local application records and sessions.

## API reference

All endpoints except `/`, `/api/health`, `/api/login`, `/api/logout`, and `/api/me` require a logged-in administrator. The browser stores the session ID in an HTTP-only cookie; JavaScript cannot read it.

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Health check |
| POST | `/api/login` | Sign in with JSON `{ "email": "...", "password": "..." }` |
| POST | `/api/logout` | Revoke current session |
| GET | `/api/me` | Return current user |
| GET | `/api/dashboard/stats` | Live totals and completion/approval percentages |
| GET | `/api/students?q=term&limit=100` | Search/list applications |
| POST | `/api/students` | Create an application |
| PATCH | `/api/students/<id>/status` | Update application status with JSON `{ "status": "Approved" }` |
| GET | `/api/activity?limit=8` | Recent activity |
| GET | `/api/reports/summary` | Counts by status, programme and term |
| GET | `/api/reports/export.csv` | Download application CSV |

### Create application JSON example

```json
{
  "full_name": "Aanya Sharma",
  "email": "aanya@example.com",
  "phone": "9876543210",
  "date_of_birth": "2005-04-18",
  "programme": "Bachelor of Computer Applications (BCA)",
  "entry_term": "January 2027",
  "notes": "Optional note"
}
```

## Project structure

```text
enrollio_fullstack/
├── app.py                 # Flask routes, validation, session/auth logic
├── requirements.txt       # Python dependencies
├── enrollio.db            # Created on first run; do not commit this file
├── templates/
│   └── index.html         # Supplied dashboard design connected to the API
└── tests/
    └── test_app.py        # Automated API tests
```

## Tests

```powershell
python -m unittest discover -s tests -v
```

Tests use a temporary SQLite database and do not modify the local demo database.

## Important limitations before production

This is a local coursework/demo application, not a production-ready admissions system. Before real deployment, add CSRF protection, login rate limiting, a secure admin password reset/change flow, HTTPS, stronger operational logging/monitoring, backups, privacy/data-retention rules, and a production WSGI server. `debug=True` is only for local development. The interface currently provides administrator management; it does not provide student self-service accounts or document uploads.
